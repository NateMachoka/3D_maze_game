Free for personal and commercial use

Full version (3 fonts)
https://crmrkt.com/B3RRy9

Follow:
https://www.instagram.com/2dfuns/
https://www.behance.net/2DFUNS